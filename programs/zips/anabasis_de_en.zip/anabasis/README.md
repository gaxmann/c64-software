# ANABASIS (Commodore 64)

ANABASIS is available in German and English. Please choose your preferred language version below.

## Versions

- English version: [`en/`](en/)
- German version: [`de/`](de/)

## Licence
Full licence text: [`en/LICENSE.txt`](en/LICENSE.txt).
